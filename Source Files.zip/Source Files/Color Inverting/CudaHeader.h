
void ProcessImage(float *rgb, float *x1,float *timeonGpu,char deviceName[]);

